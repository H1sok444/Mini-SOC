#!/bin/bash
logger -t sshd "Failed password for invalid user test1 from 203.0.113.5 port 50234 ssh2"
logger -t sshd "Failed password for invalid user test1 from 203.0.113.5 port 50234 ssh2"
logger -t sshd "Accepted password for backupuser from 203.0.113.5 port 50234 ssh2"
