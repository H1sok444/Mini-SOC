from selenium import webdriver
from selenium.webdriver.common.by import By
import os

WAZUH_URL = os.getenv("WAZUH_URL","https://localhost")

def test_dashboard_reachable():
    options = webdriver.ChromeOptions()
    options.add_argument("--headless=new")
    driver = webdriver.Chrome(options=options)
    driver.get(WAZUH_URL)
    assert "Wazuh" in driver.title or "Wazuh" in driver.page_source
    driver.quit()
