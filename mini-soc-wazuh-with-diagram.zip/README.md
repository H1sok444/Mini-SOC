# Mini SOC Wazuh

This repo contains:
- Docker Swarm stack for Wazuh + Traefik
- GitHub Actions CI/CD pipeline with Trivy and Selenium tests
- Ansible playbooks to deploy idempotently to Swarm
- Custom Wazuh rule for SSH suspicious login detection

See docs/ for HLD/LLD and assumptions.

## Architecture Diagram

![Mini SOC Architecture](docs/mini-soc-architecture.png)
